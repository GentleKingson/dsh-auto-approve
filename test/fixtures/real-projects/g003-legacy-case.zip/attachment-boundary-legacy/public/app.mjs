import { decorateRows } from './view-model.mjs';
const $ = id => document.getElementById(id);
const state = { tenant: 'T-A', master: 'M-100', rows: [] };
const request = async (path, options = {}) => {
  const resp = await fetch(path, {
    ...options,
    headers: { 'x-tenant-id': state.tenant, 'content-type': 'application/json', ...options.headers }
  });
  const json = await resp.json();
  if (!resp.ok) throw new Error(json.error || `HTTP ${resp.status}`);
  return json;
};
const addText = (el, tag, txt, cls = '') => {
  const n = document.createElement(tag);
  n.textContent = String(txt);
  if (cls) n.className = cls;
  el.appendChild(n);
  return n;
};
const names = files => files.length ? files.map(x => x.name).join('、') : '（无）';

async function refresh() {
  state.tenant = $('tenant').value;
  state.master = $('master').value;
  try {
    const [master, children] = await Promise.all([
      request(`/api/masters/${state.master}`),
      request(`/api/masters/${state.master}/children`)
    ]);
    const ml = $('master-attachments'); ml.replaceChildren();
    for (const file of master.attachments) addText(ml, 'li', `${file.name} · ${file.ownerType}/${file.ownerId}`);
    if (!master.attachments.length) addText(ml, 'li', '（无）');

    state.rows = decorateRows(children.rows, master.attachments);
    const tbody = $('child-rows'); tbody.replaceChildren();
    const target = $('child-target'); target.replaceChildren();
    for (const row of state.rows) {
      const tr = document.createElement('tr');
      addText(tr, 'td', `${row.title} (${row.id})`);
      addText(tr, 'td', row.attachmentCount);
      addText(tr, 'td', names(row.ownAttachments));
      const ops = document.createElement('td');
      const btn = addText(ops, 'button', '查看来源');
      btn.type = 'button'; btn.onclick = () => showRelated(row.id);
      tr.appendChild(ops); tbody.appendChild(tr);
      const option = document.createElement('option');
      option.value = row.id; option.textContent = `${row.id} · ${row.title}`; target.appendChild(option);
    }
    if (!state.rows.length) {
      const tr = document.createElement('tr');
      const td = addText(tr, 'td', '暂无子单'); td.colSpan = 4; tbody.appendChild(tr);
    }
    $('status').textContent = '查询成功。';
    $('child-detail').textContent = '点击「查看来源」查看自有与来自主单的资料。';
  } catch (e) { $('status').textContent = e.message; }
}
async function showRelated(childId) {
  try {
    const data = await request(`/api/children/${childId}/attachments?view=related`);
    const area = $('child-detail'); area.replaceChildren();
    addText(area, 'h3', `${childId} · 自有附件`);
    addText(area, 'p', names(data.owned));
    addText(area, 'h3', '来自主单（关联资料，不计入自有）');
    addText(area, 'p', names(data.inheritedFromMaster));
  } catch (e) { $('status').textContent = e.message; }
}
async function upload(e, kind) {
  e.preventDefault();
  const id = kind === 'masters' ? state.master : $('child-target').value;
  const input = $(kind === 'masters' ? 'master-name' : 'child-name');
  if (!id) return;
  try {
    await request(`/api/${kind}/${id}/attachments`, {
      method: 'POST', body: JSON.stringify({ name: input.value })
    });
    input.value = '';
    await refresh();
  } catch (e) { $('status').textContent = e.message; }
}
$('refresh').addEventListener('click', refresh);
$('tenant').addEventListener('change', refresh);
$('master').addEventListener('change', refresh);
$('upload-master').addEventListener('submit', e => upload(e, 'masters'));
$('upload-child').addEventListener('submit', e => upload(e, 'children'));
refresh();
