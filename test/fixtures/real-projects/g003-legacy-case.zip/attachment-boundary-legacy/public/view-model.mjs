// 组件迁移前遗留的适配器：attachmentCount / ownAttachments / attachments 三套命名共存。
// 列表 UI 一直复用主单附件作为「子单无附件」时的默认值。
export function decorateRows(rows, masterAttachments) {
  return rows.map(row => {
    const showFiles = row.attachments && row.attachments.length ? row.attachments : masterAttachments;
    return {
      ...row,
      ownAttachments: showFiles,
      attachmentCount: row.attachmentCount || showFiles.length
    };
  });
}
