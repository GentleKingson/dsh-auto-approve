# G-003 · 附件归属边界越界（遗留代码实战）

**这是刻意带缺陷的前后端练习项目，不要当作可部署的真实业务系统。**

## 题目背景

系统有两个不同层级的业务单据：**主单（MASTER）**和**子单（CHILD）**，两者都能上传附件。

- 主单页面「主单附件」必须仅展示 **直接归属主单** 的已发布附件。
- 主单下面的「子单列表 → 本子单的附件 / 自有附件数」，必须只展示或统计 **直接归属该子单** 的已发布附件。
- 子单详情的 `owned` 也是直接归属；`view=related` 才可以展示「关联来源主单」的附件，但必须放到 `inheritedFromMaster`，不得算入 `owned`。
- **单据链字段 `chainId` 仅表明业务关联，不能证明附件直接归属。** 即使主单与子单同号，也必须按归属的实体类型和实体 ID 区分。
- 数据以租户隔离；相同业务编号可以在不同租户复用。演示使用 `x-tenant-id` 作为测试环境租户选择器，**不是生产鉴权实现**。
- 仅有 `state === 'READY'` 且 `deletedAt === null` 的附件参与查询与计数。
- 上传一个附件应立即被对应归属方查询到（不要求重启），其他归属方的自有附件集合不得被改变。

## 当前错误现象

主单 `M-100` 上传了 `A-1 招标文件.pdf` 和 `A-9 报价清单.xlsx`，子单 `C-101` 只上传了 `A-2 验收照片.jpg`，另一个子单 `C-102` 只上传了 `A-3 签收单.pdf`。

但当前代码会将主单和兄弟子单附件混进「本子单附件」里；未命中的空值分支还会让网页把主单附件回填到子单自有附件栏。历史缓存的 key 与失效逻辑也不一致。

## 本地运行（不需 npm install，零第三方依赖）

要求 Node.js >=20。

```bash
npm start
# 访问 http://127.0.0.1:3000
npm test
```

**原始状态预期：** 3 个 baseline 测试通过，3 个 G-003 regression 测试失败。红色测试是题目的一部分。

API 示例：

```bash
curl -H 'x-tenant-id: T-A' http://127.0.0.1:3000/api/masters/M-100/children
curl -H 'x-tenant-id: T-A' 'http://127.0.0.1:3000/api/children/C-101/attachments?view=related'
curl -H 'x-tenant-id: T-A' -H 'content-type: application/json' \
  -d '{"name":"new-child-file.pdf"}' http://127.0.0.1:3000/api/children/C-101/attachments
```

## 稳定 API 契约

| 方法 | 路径 | 正常返回 |
| --- | --- | --- |
| GET | `/api/health` | `{ok:true}` |
| GET | `/api/masters/:id` | `{id,title,attachments:[...]}` |
| GET | `/api/masters/:id/children` | `{masterId,rows:[{id,masterId,title,attachments,attachmentCount}]}` |
| GET | `/api/children/:id/attachments?view=owned` | `{childId,owned:[...],inheritedFromMaster:[]}` |
| GET | `/api/children/:id/attachments?view=related` | `{childId,owned:[...],inheritedFromMaster:[...]}` |
| POST | `/api/masters/:id/attachments` | `{attachment:...}`，201 |
| POST | `/api/children/:id/attachments` | `{attachment:...}`，201 |

附件公开结构是 `{id,name,tenantId,ownerType,ownerId,createdSeq}`。列表 `attachmentCount` 必须等于 `attachments.length`。有效结果按 `createdSeq` 升序排列。未知资源须返回 404；非法附件名返回 400；无效 view 返回 400。

测试可调用 `src/server.mjs` 导出的 **`createApp({seedData})`** 注入不同租户、订单和附件数据；该入口和 HTTP 契约不可移除。网页数据适配器 `public/view-model.mjs` 的 **`decorateRows(rows, masterAttachments)`** 及其 `ownAttachments` 输出也不可移除。

文件上传模拟的是「文件元数据登记」，不需要实现真实二进制存储、上传签名、数据库或身份认证。

## 任务

阅读 [AI_TASK.md](AI_TASK.md)，自行定位造成归属污染的链路，**最小范围修复**，保证业务契约不变。禁止仅修改测试、只把附件数隐藏、直接清空附件、硬编码样本 ID，或把主单附件移交给子单。
