import { createApp } from '../src/server.mjs';

export async function withApp(t, run, seedData) {
  const server = createApp({ seedData });
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  t.after(() => new Promise((resolve, reject) => server.close(err => err ? reject(err) : resolve())));
  const base = `http://127.0.0.1:${server.address().port}`;
  return run(async (path, { tenant = 'T-A', method = 'GET', body } = {}) => {
    const res = await fetch(`${base}${path}`, {
      method,
      headers: { 'x-tenant-id': tenant, 'content-type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) })
    });
    return { status: res.status, data: await res.json() };
  });
}
export const ids = files => files.map(x => x.id);
