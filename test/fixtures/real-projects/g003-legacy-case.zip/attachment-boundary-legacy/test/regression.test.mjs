import { test } from 'node:test';
import assert from 'node:assert/strict';
import { withApp, ids } from './helpers.mjs';
import { decorateRows } from '../public/view-model.mjs';

// 这三个公开测试会在原始版本失败，修复后应变绿；裁判还有独立场景。
test('G-003：列表里的「本子单附件」不能混入主单及兄弟子单文件', async t => {
  await withApp(t, async request => {
    const { data } = await request('/api/masters/M-100/children');
    const first = data.rows.find(x => x.id === 'C-101');
    const second = data.rows.find(x => x.id === 'C-102');
    assert.deepEqual(ids(first.attachments), ['A-2']);
    assert.deepEqual(ids(second.attachments), ['A-3']);
    assert.equal(first.attachmentCount, 1);
    assert.equal(second.attachmentCount, 1);
  });
});

test('G-003：子单详情中的 owned 仅包含直接归属，关联上游须独立分组', async t => {
  await withApp(t, async request => {
    const { data } = await request('/api/children/C-101/attachments?view=related');
    assert.deepEqual(ids(data.owned), ['A-2']);
    assert.deepEqual(ids(data.inheritedFromMaster), ['A-1', 'A-9']);
  });
});

test('G-003：前端不可以把主单附件回填到空子单的自有附件栏', () => {
  const rows = [{ id: 'C-EMPTY', title: '无附件子单', attachments: [], attachmentCount: 0 }];
  const parent = [{ id: 'PARENT-FILE', name: '主单附件.pdf' }];
  const actual = decorateRows(rows, parent);
  assert.deepEqual(actual[0].ownAttachments, []);
  assert.equal(actual[0].attachmentCount, 0);
});
