import { test } from 'node:test';
import assert from 'node:assert/strict';
import { withApp, ids } from './helpers.mjs';

test('健康检查以及主单详情的直接归属保持正常', async t => {
  await withApp(t, async request => {
    assert.deepEqual((await request('/api/health')).data, { ok: true });
    const result = await request('/api/masters/M-100');
    assert.equal(result.status, 200);
    assert.deepEqual(ids(result.data.attachments), ['A-1', 'A-9']);
    assert.ok(result.data.attachments.every(x => x.ownerType === 'MASTER' && x.ownerId === 'M-100'));
  });
});

test('现有上传功能：主单上传归主单，不应破坏', async t => {
  await withApp(t, async request => {
    const result = await request('/api/masters/M-100/attachments', {
      method: 'POST', body: { name: '新上传合同.pdf' }
    });
    assert.equal(result.status, 201);
    assert.equal(result.data.attachment.ownerType, 'MASTER');
    assert.equal(result.data.attachment.ownerId, 'M-100');
    const master = await request('/api/masters/M-100');
    assert.equal(master.data.attachments.length, 3);
  });
});

test('输入和不存在的单据仍应正常报错', async t => {
  await withApp(t, async request => {
    assert.equal((await request('/api/children/NO-SUCH/attachments')).status, 404);
    assert.equal((await request('/api/masters/NO-SUCH/children')).status, 404);
    assert.equal((await request('/api/children/C-101/attachments', {
      method: 'POST', body: { name: '  ' }
    })).status, 400);
    assert.equal((await request('/api/children/C-101/attachments?view=unknown')).status, 400);
  });
});
