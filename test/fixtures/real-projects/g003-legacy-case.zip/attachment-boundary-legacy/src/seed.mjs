// 一次迁移留下的演示数据；同一数字/业务编号可以在不同租户重复。
const f = (id, tenantId, ownerType, ownerId, chainId, name, createdSeq, extra = {}) => ({
  id, tenantId, ownerType, ownerId, chainId, name, createdSeq,
  state: 'READY', deletedAt: null, ...extra
});

export function makeSeedData() {
  return {
    masters: [
      { tenantId: 'T-A', id: 'M-100', title: '华东采购总单' },
      { tenantId: 'T-A', id: 'M-200', title: '华北设备总单' },
      { tenantId: 'T-B', id: 'M-100', title: '外部同号总单' }
    ],
    children: [
      { tenantId: 'T-A', id: 'C-101', masterId: 'M-100', title: '第一配送分单' },
      { tenantId: 'T-A', id: 'C-102', masterId: 'M-100', title: '第二配送分单' },
      { tenantId: 'T-A', id: 'C-103', masterId: 'M-200', title: '设备安装分单' },
      { tenantId: 'T-B', id: 'C-101', masterId: 'M-100', title: '外部同号分单' }
    ],
    files: [
      f('A-1', 'T-A', 'MASTER', 'M-100', 'M-100', '招标文件.pdf', 1),
      f('A-2', 'T-A', 'CHILD', 'C-101', 'M-100', '验收照片.jpg', 2),
      f('A-3', 'T-A', 'CHILD', 'C-102', 'M-100', '签收单.pdf', 3),
      f('A-4', 'T-A', 'MASTER', 'M-200', 'M-200', '设备采购合同.pdf', 4),
      f('A-5', 'T-A', 'CHILD', 'C-101', 'M-100', '删除的草稿.png', 5, {deletedAt: '2026-09-01T10:00:00Z'}),
      f('A-6', 'T-A', 'CHILD', 'C-102', 'M-100', '未完成上传.zip', 6, {state: 'PENDING'}),
      f('B-1', 'T-B', 'MASTER', 'M-100', 'M-100', 'B租户主单合同.pdf', 7),
      f('B-2', 'T-B', 'CHILD', 'C-101', 'M-100', 'B租户子单明细.pdf', 8),
      f('A-9', 'T-A', 'MASTER', 'M-100', 'M-100', '报价清单.xlsx', 9)
    ]
  };
}
