import { makeSeedData } from './seed.mjs';

// 这是一个无数据库的运行样本：模拟关系表 + 旧缓存层，便于离线复现。
export function createStore(seedData = makeSeedData()) {
  const x = structuredClone(seedData);
  return {
    masters: x.masters,
    children: x.children,
    files: x.files,
    cache: new Map(),
    counter: 0
  };
}

export function findMaster(db, tenantId, id) {
  return db.masters.find(x => x.tenantId === tenantId && x.id === id);
}

export function findChild(db, tenantId, id) {
  return db.children.find(x => x.tenantId === tenantId && x.id === id);
}

// 三年前的缓存撤销入口；调用者未必知道真实缓存 key 的拼法。
export function oldInvalidate(db, tenantId, masterId) {
  db.cache.delete(`CHILD_LIST:${tenantId}:${masterId}`);
  db.cache.delete(`MASTER_FILE:${masterId}`);
}
