import { findMaster, findChild, oldInvalidate } from '../store.mjs';
import { publicFile } from './file-join.mjs';

export function uploadAttachment(db, tenantId, kind, id, name) {
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 120) {
    return { code: 400, error: 'name must be 1..120 characters' };
  }
  const target = kind === 'MASTER' ? findMaster(db, tenantId, id) : findChild(db, tenantId, id);
  if (!target) return { code: 404, error: 'order not found' };
  const parentKey = kind === 'MASTER' ? id : target.masterId;
  db.counter++;
  const row = {
    id: `UP-${db.counter}`, tenantId, ownerType: kind, ownerId: id,
    chainId: parentKey, name: name.trim(),
    createdSeq: Math.max(0, ...db.files.map(x => x.createdSeq)) + 1,
    state: 'READY', deletedAt: null
  };
  db.files.push(row);
  // 历史兼容：上游的某个查询仍把 chainId 看作附件归属；此处不能修改原始归属。
  oldInvalidate(db, tenantId, parentKey);
  return { code: 201, attachment: publicFile(row) };
}
