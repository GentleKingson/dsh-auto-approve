// 历史背景：原系统里一个 chainId 既是「单据链根 ID」，又被多个页面当做
// 「附件归属 ID」。几个功能模块复用这一段，逻辑已经越写越宽。
export function publicFile(x) {
  return {
    id: x.id, name: x.name, tenantId: x.tenantId,
    ownerType: x.ownerType, ownerId: x.ownerId, createdSeq: x.createdSeq
  };
}

export function isPublished(x) {
  return x.state === 'READY' && !x.deletedAt;
}

export function selectLegacyFiles(db, opts) {
  const what = opts.kind || 'CHILD';
  const rootId = opts.masterId || opts.id;
  // 当时为了做「整个业务链附件」，在这里补了一个 OR，后来复用到自有附件。
  const bag = db.files.filter(x => isPublished(x) && (
    x.tenantId === opts.tenantId || (what !== 'MASTER' && x.chainId === rootId)
  ));
  const found = bag.filter(x => what === 'MASTER'
    ? (x.tenantId === opts.tenantId && x.ownerType === 'MASTER' && x.ownerId === opts.id)
    : (x.ownerId === opts.id || x.chainId === rootId || x.ownerId === opts.masterId)
  );
  return found.sort((a, b) => a.createdSeq - b.createdSeq).map(publicFile);
}
