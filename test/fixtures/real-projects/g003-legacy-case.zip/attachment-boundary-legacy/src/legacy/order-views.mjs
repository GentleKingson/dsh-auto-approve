import { findMaster, findChild } from '../store.mjs';
import { selectLegacyFiles } from './file-join.mjs';

export function masterView(db, tenantId, masterId) {
  const item = findMaster(db, tenantId, masterId);
  if (!item) return null;
  return {
    id: item.id, title: item.title,
    attachments: selectLegacyFiles(db, { tenantId, kind: 'MASTER', id: item.id })
  };
}

export function childListView(db, tenantId, masterId) {
  if (!findMaster(db, tenantId, masterId)) return null;
  // 上个版本为了加速列表页，把缓存按主单 ID 建立；没有把租户算进 key。
  const k = `MASTER_CHILDREN:${masterId}`;
  const cached = db.cache.get(k);
  if (cached) return structuredClone(cached);

  const candidates = db.children.filter(x => x.tenantId === tenantId && x.masterId === masterId);
  const rows = candidates.map(x => {
    const temp = selectLegacyFiles(db, {
      tenantId, kind: 'CHILD', id: x.id, masterId: x.masterId
    });
    return {
      id: x.id, masterId: x.masterId, title: x.title,
      attachments: temp,
      attachmentCount: temp.length
    };
  });
  const result = { masterId, rows };
  db.cache.set(k, structuredClone(result));
  return result;
}

export function childAttachmentsView(db, tenantId, childId, view = 'related') {
  const child = findChild(db, tenantId, childId);
  if (!child) return null;
  const owned = selectLegacyFiles(db, {
    tenantId, kind: 'CHILD', id: child.id, masterId: child.masterId
  });
  // 「关联资料」允许显示上游主单附件，但必须单独声明来源。
  const inheritedFromMaster = view === 'related'
    ? selectLegacyFiles(db, { tenantId, kind: 'MASTER', id: child.masterId })
    : [];
  return { childId: child.id, owned, inheritedFromMaster };
}
