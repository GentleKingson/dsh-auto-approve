import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve } from 'node:path';
import { createStore } from './store.mjs';
import { masterView, childListView, childAttachmentsView } from './legacy/order-views.mjs';
import { uploadAttachment } from './legacy/write-api.mjs';

const folder = dirname(fileURLToPath(import.meta.url));
const staticMap = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/app.mjs': ['app.mjs', 'text/javascript; charset=utf-8'],
  '/view-model.mjs': ['view-model.mjs', 'text/javascript; charset=utf-8'],
  '/styles.css': ['styles.css', 'text/css; charset=utf-8']
};

function send(res, code, data) {
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(data));
}
function collect(req) {
  return new Promise((resolveBody, reject) => {
    let text = '';
    req.on('data', chunk => {
      text += chunk;
      if (text.length > 64 * 1024) req.destroy(new Error('body too large'));
    });
    req.on('end', () => {
      try { resolveBody(JSON.parse(text || '{}')); } catch { reject(new Error('bad json')); }
    });
    req.on('error', reject);
  });
}

// 裁判的黑盒入口：允许注入一套任意的单据/附件样本，不得移除。
export function createApp({ seedData } = {}) {
  const db = createStore(seedData);
  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const p = url.pathname.split('/').filter(Boolean);
    // 演示租户选择，不是鉴权机制；真实生产应用必须从已验证身份获取租户。
    const tenantId = String(req.headers['x-tenant-id'] || 'T-A');
    try {
      if (req.method === 'GET' && url.pathname === '/api/health') {
        return send(res, 200, { ok: true });
      }
      if (req.method === 'GET' && p[0] === 'api' && p[1] === 'masters' && p.length === 3) {
        const data = masterView(db, tenantId, p[2]);
        return send(res, data ? 200 : 404, data || { error: 'master not found' });
      }
      if (req.method === 'GET' && p[0] === 'api' && p[1] === 'masters' && p[3] === 'children' && p.length === 4) {
        const data = childListView(db, tenantId, p[2]);
        return send(res, data ? 200 : 404, data || { error: 'master not found' });
      }
      if (req.method === 'GET' && p[0] === 'api' && p[1] === 'children' && p[3] === 'attachments' && p.length === 4) {
        const view = url.searchParams.get('view') || 'related';
        if (!['owned', 'related'].includes(view)) return send(res, 400, { error: 'invalid view' });
        const data = childAttachmentsView(db, tenantId, p[2], view);
        return send(res, data ? 200 : 404, data || { error: 'child not found' });
      }
      if (req.method === 'POST' && p[0] === 'api' && p[3] === 'attachments' && p.length === 4 && (p[1] === 'masters' || p[1] === 'children')) {
        let body;
        try { body = await collect(req); } catch { return send(res, 400, { error: 'invalid request body' }); }
        const kind = p[1] === 'masters' ? 'MASTER' : 'CHILD';
        const result = uploadAttachment(db, tenantId, kind, p[2], body.name);
        return send(res, result.code, result.code === 201 ? { attachment: result.attachment } : { error: result.error });
      }
      if (req.method === 'GET' && Object.hasOwn(staticMap, url.pathname)) {
        const [name, type] = staticMap[url.pathname];
        const data = await readFile(resolve(folder, '../public', name));
        res.writeHead(200, { 'content-type': type });
        return res.end(data);
      }
      send(res, 404, { error: 'not found' });
    } catch (error) {
      // 历史应用保留整条错误日志，外部响应不暴露堆栈。
      console.error(error);
      send(res, 500, { error: 'internal error' });
    }
  });
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  const port = Number(process.env.PORT || 3000);
  const server = createApp();
  server.listen(port, '127.0.0.1', () => {
    console.log(`G-003 legacy demo: http://127.0.0.1:${server.address().port}`);
  });
}
